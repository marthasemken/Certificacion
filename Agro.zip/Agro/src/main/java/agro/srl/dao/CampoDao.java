/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agro.srl.dao;

import agro.srl.poo.Campo;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

/**
 *
 * @author Martha
 */
public class CampoDao {
    private final SessionFactory sessionFactory;
    
   
    
    public CampoDao( SessionFactory sessionFactory) {
        
        this.sessionFactory = sessionFactory;
    }
    
    
   
    
    public boolean estaNombre(String nombre)
    {
        Campo tipo = null;
        Session session = sessionFactory.openSession();
        
        CriteriaBuilder builder =session.getCriteriaBuilder();
        CriteriaQuery<Campo> query =builder.createQuery(Campo.class);
        Root<Campo> root = query.from(Campo.class);
        query.select(root);
        query.where(builder.equal(root.get("nombre"), nombre));
        tipo = session.createQuery(query).uniqueResult();
        session.close(); 
        
    return tipo==null?true:false; 
    
    }
    
    
     public Long obtenerNumero() {
        Session session = sessionFactory.openSession();
        
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<Long> query = builder.createQuery(Long.class);
        Root<Campo> root = query.from(Campo.class);
        query.select(builder.max(root.get("id")));
        
        Long ultimo = session.createQuery(query).uniqueResult();
        
        session.close();
        
        return  ultimo;
    }
    
    public void guardar(Campo campo) {
        Session session = this.sessionFactory.openSession();
        session.beginTransaction();
        session.save(campo);
        session.getTransaction().commit();
        session.close();
    }
}
