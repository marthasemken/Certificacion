/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agro.srl.dao;

import agro.srl.poo.TipoSuelo;
import java.util.List;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

/**
 *
 * @author Martha
 */
public class TipoSueloDao {
    private final SessionFactory sessionFactory;
    
   
    
    public TipoSueloDao( SessionFactory sessionFactory) {
        
        this.sessionFactory = sessionFactory;
    }
    
    
    public List<TipoSuelo> tiposSuelo() {       
        
        List<TipoSuelo> tipoSuelo = null; 
        Session session = sessionFactory.openSession();
        List<TipoSuelo> pedidos = session.createQuery("from tipo_suelo").list();
        session.close();
        return tipoSuelo;
    }
    
    public TipoSuelo buscarNombre(String nombre)
    {
        TipoSuelo tipo = null;
        Session session = sessionFactory.openSession();
        
        CriteriaBuilder builder =session.getCriteriaBuilder();
        CriteriaQuery<TipoSuelo> query =builder.createQuery(TipoSuelo.class);
        Root<TipoSuelo> root = query.from(TipoSuelo.class);
        query.select(root);
        query.where(builder.equal(root.get("nombre"), nombre));
        tipo = session.createQuery(query).uniqueResult();
        session.close(); 
    
    return tipo; 
    
    }

}
