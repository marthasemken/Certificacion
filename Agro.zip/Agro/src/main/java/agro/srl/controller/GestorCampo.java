/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agro.srl.controller;

import agro.srl.dao.CampoDao;
import agro.srl.dao.LoteDao;
import agro.srl.dao.TipoSueloDao;
import agro.srl.poo.Campo;
import agro.srl.poo.Lote;
import agro.srl.poo.TipoSuelo;
import agro.srl.ui.PantallaRegistroCampo;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.SessionFactory;

/**
 *
 * @author Martha
 */
public class GestorCampo {
  /*  private final EstadosPedidoDao estadosPedidoDao;
    private final EstadosFacturaDao estadosFacturaDao;
    private final FacturasDao facturasDao;
    private Pedido pedido;*/
    private TipoSueloDao tipoSuelo;
    private CampoDao campo;
    private LoteDao lote;
    
    public GestorCampo(SessionFactory   sessionFactory )
    {
    
        tipoSuelo= new TipoSueloDao(sessionFactory);
        campo= new CampoDao(sessionFactory);
        lote = new LoteDao(sessionFactory);
       /* this.estadosPedidoDao = new EstadosPedidoDaoHibernateImpl(sessionFactory);
        this.estadosFacturaDao = new EstadosFacturaDaoHibernateImpl(sessionFactory);
        this.pedidosDao = new PedidosDaoHibernateImpl(estadosPedidoDao, sessionFactory);
        this.facturasDao = new FacturasDaoHibernateImpl(sessionFactory);*/
    }
    
    public void run () {
        new PantallaRegistroCampo(this).setVisible(true);
    }
    
     public List<TipoSuelo> tiposSuelo () {
        return tipoSuelo.tiposSuelo();
    }
     
     public boolean estaNombreCampo(String nombre)
     {
         return campo.estaNombre(nombre);
     }
     
     public void guardarCampo(String nombre, Integer superficie, List<Lote> lotes)
     {
          campo.guardar(new Campo(nombre,superficie));
          Long numero=campo.obtenerNumero();
          for(Lote lote: lotes)
          {              
              this.lote.guardar(lote);
          }
                  
     }
}


