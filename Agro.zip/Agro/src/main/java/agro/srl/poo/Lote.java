package agro.srl.poo;



public class Lote {
        private Integer id;
	private Integer numero;
	private TipoSuelo tipoSuelo;
	private Integer superficie;        
	public  Lote() {
	
	}

    public Lote(Integer numero, TipoSuelo tipoSuelo, Integer superficie) {
        this.numero = numero;
        this.tipoSuelo = tipoSuelo;
        this.superficie = superficie;
    }
	
	public void unirLotes(Lote lote) {
            if (getTipoSuelo().equals(lote.getTipoSuelo()))
            {   
                this.superficie+=lote.superficie;
            }
            else
                throw new RuntimeException("No tienen el mismo tipo de suelo");
	}
	
	public Lote dividirLote(Integer num, Integer superficie) {
	
            Lote nuevo=null;
            if(this.superficie>superficie)
            {
                nuevo=new Lote(num,new TipoSuelo(tipoSuelo.getNumero(),tipoSuelo.getNombre(),tipoSuelo.getCaracteristicas()),superficie);
                this.superficie-=superficie;
            }
            else
            {
             throw new RuntimeException("No hay suficiente superficie");
            }
            return nuevo;
            
	}
	
	public TipoSuelo verTipoSuelo() {
            return tipoSuelo;
	}

    public Integer getNumero() {
        return numero;
    }

    public void setNumero(Integer numero) {
        this.numero = numero;
    }

    public TipoSuelo getTipoSuelo() {
        return tipoSuelo;
    }

    public void setTipoSuelo(TipoSuelo tipoSuelo) {
        this.tipoSuelo = tipoSuelo;
    }

    public Integer getSuperficie() {
        return superficie;
    }

    public void setSuperficie(Integer superficie) {
        this.superficie = superficie;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
        
        
}
