package agro.srl.poo;

//

import java.util.ArrayList;




public class Campo {
        private Integer id;
	private String nombre;
	private Integer superficie;
	private ArrayList<Lote> lotes;
	private EstadoCampo estadoCampo;
	private ArrayList<Proyecto> proyectos;
        
        public Campo() {
	
	}

    public Campo(String nombre, Integer supeficie) {
        this.nombre = nombre;
        this.superficie=superficie;
        estadoCampo.setNombre("Creado");
    }

    

    public ArrayList<Proyecto> getProyectos() {
        return proyectos;
    }

    public void setProyectos(ArrayList<Proyecto> proyectos) {
        this.proyectos = proyectos;
    }
	
	public void agregarLote(Lote lote) {
            lotes.add(lote);
	}
	
        public void agregarProyecto(Lote proyecto) {
            lotes.add(proyecto);
	}
        
	public ArrayList<Lote> verLotes() {
	
            return lotes;
	}
	
	public EstadoCampo verEstadoCampo() {
	
            return estadoCampo;
	}
	
	public ArrayList<Proyecto> verProyectos() {
	
            return proyectos;
	}
	
	public void unirLotes() {
	
	}
        
        public boolean esCreado() {
            
            return estadoCampo.esCreado();
	}
	
	public boolean esParcialmenteTrabajado() {
	
            return estadoCampo.esParcialmenteTrabajado();
	}
	
	public boolean esCompletamenteTrabajado() {
	
            return estadoCampo.esCompletamenteTrabajado();
	}
	
	public boolean esDesuso() {
	
            return estadoCampo.esDesuso();
	}
        
        
        
        public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Integer getSuperficie() {
        return superficie;
    }

    public void setSuperficie(Integer superficie) {
        this.superficie = superficie;
    }

    public ArrayList<Lote> getLotes() {
        return lotes;
    }

    public void setLotes(ArrayList<Lote> lotes) {
        this.lotes = lotes;
    }

    public EstadoCampo getEstadoCampo() {
        return estadoCampo;
    }

    public void setEstadoCampo(EstadoCampo estadoCampo) {
        this.estadoCampo = estadoCampo;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
    
}
