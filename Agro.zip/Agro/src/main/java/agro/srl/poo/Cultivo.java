package agro.srl.poo;

//

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;





public class Cultivo {
	private String nombre;
	private TipoSuelo tipoSuelo;
	private ArrayList<Plaga> plagas;
	private ArrayList<Laboreo> laboreos;        
        
	public  Cultivo() {
	
	}
	
	public ArrayList<Plaga> verPlagas() {
            
            return plagas;
	}
	
	public void agregarPlaga(Plaga plaga) {
	
            plagas.add(plaga);
	}
	
	public ArrayList<Laboreo> verLaboreo() {
	
            return laboreos;
	}	
        
	public void agregarLaboreo(Laboreo laboreo, Integer dias) {
	
           
            laboreo.setFecha(calcularFechaLaboreo(dias));
            laboreos.add(laboreo);
	}
	
	private Calendar calcularFechaLaboreo(Integer dias) {
             Calendar ultimaFecha = ultimoLaboreo().getFecha();
            Calendar nuevaFecha = Calendar.getInstance();
            nuevaFecha.set(ultimaFecha.get(Calendar.YEAR),ultimaFecha.get(Calendar.MONTH),ultimaFecha.get(Calendar.DAY_OF_MONTH));
            ultimaFecha.add(Calendar.DATE,dias);
            return ultimaFecha;
	}
	
	public TipoSuelo verTipoSuelo() {
            return tipoSuelo;
	}
	
	public void crearLaboreos(Calendar fecha) {
	  
            laboreos= new ArrayList<>();
            Laboreo inicial=new Laboreo(new TipoLaboreo(0,"Incio"),fecha);
            
	}

    public Laboreo ultimoLaboreo()    
    {
        return laboreos.get(laboreos.size()-1);
    }
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public TipoSuelo getTipoSuelo() {
        return tipoSuelo;
    }

    public void setTipoSuelo(TipoSuelo tipoSuelo) {
        this.tipoSuelo = tipoSuelo;
    }

    public ArrayList<Plaga> getPlagas() {
        return plagas;
    }

    public void setPlagas(ArrayList<Plaga> plagas) {
        this.plagas = plagas;
    }

    public ArrayList<Laboreo> getLaboreos() {
        return laboreos;
    }

    public void setLaboreos(ArrayList<Laboreo> laboreos) {
        this.laboreos = laboreos;
    }

   
        
        
}
