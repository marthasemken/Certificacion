package agro.srl.poo;



import java.util.Objects;





public class TipoSuelo {
        private Integer id;
	private Integer numero;        
	private String nombre;
	private String caracteristicas;
	public  TipoSuelo() {
	
	}

    public TipoSuelo(Integer numero, String nombre, String caracteristicas) {
        this.numero = numero;
        this.nombre = nombre;
        this.caracteristicas = caracteristicas;
    }
        

    public Integer getNumero() {
        return numero;
    }

    public void setNumero(Integer numero) {
        this.numero = numero;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCaracteristicas() {
        return caracteristicas;
    }

    public void setCaracteristicas(String caracteristicas) {
        this.caracteristicas = caracteristicas;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return  nombre;
    }

    

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final TipoSuelo other = (TipoSuelo) obj;
        if (!Objects.equals(this.numero, other.numero)) {
            return false;
        }
        return true;
    }
        
    
        
}
