package agro.srl.poo;


public class TipoLaboreo {
	private int tipoLaboreo;        
	private String nombre;
        
	public  TipoLaboreo() {
	
	}

    public TipoLaboreo(int tipoLaboreo, String nombre) {
        this.tipoLaboreo = tipoLaboreo;
        this.nombre = nombre;
    }

    public int getTipoLaboreo() {
        return tipoLaboreo;
    }

    public void setTipoLaboreo(int tipoLaboreo) {
        this.tipoLaboreo = tipoLaboreo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
        
}
