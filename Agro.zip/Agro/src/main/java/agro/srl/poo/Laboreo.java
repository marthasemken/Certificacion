package agro.srl.poo;


import java.util.Calendar;





public class Laboreo {
    
	private TipoLaboreo tipoLaboreo;
	private String descripcion;
	private Calendar fecha;
        
	public  Laboreo() {
	
	}

    public Laboreo(TipoLaboreo tipoLaboreo, Calendar fecha) {
        this.tipoLaboreo = tipoLaboreo;
        this.fecha = fecha;
    }
        

    public TipoLaboreo getTipoLaboreo() {
        return tipoLaboreo;
    }

    public void setTipoLaboreo(TipoLaboreo tipoLaboreo) {
        this.tipoLaboreo = tipoLaboreo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Calendar getFecha() {
        return fecha;
    }

    public void setFecha(Calendar fecha) {
        this.fecha = fecha;
    }
        
	
	
}
