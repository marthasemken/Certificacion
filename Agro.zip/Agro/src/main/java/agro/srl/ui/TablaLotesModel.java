/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agro.srl.ui;

import agro.srl.poo.Lote;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Martha
 */
public class TablaLotesModel extends AbstractTableModel  {

    
    private static final String[] COLUMNAS = { "Número", "Superficie", "TipoSuelo" };
    private List<Lote> lotes;
    
     public TablaLotesModel (List<Lote> lotes) {
        super();
        this.lotes = lotes;
    }
    
    @Override
    public int getRowCount() {
        return lotes.size();
    }

    @Override
    public int getColumnCount() {
        return  COLUMNAS.length;
    }

    @Override
    public Object getValueAt(int fila, int columna) {
        
        Object aux =null;
        Lote lote=lotes.get(fila);
        switch (columna)
        {
            case 0:
                aux=lote.getNumero();
                break;
            case 1:
                aux=lote.getSuperficie();
                break;
            case 2:
                aux=lote.getTipoSuelo();
                break;
        }
        return aux;
    }
    
      
    @Override
    public String getColumnName(int index) {
        return COLUMNAS[index];
    }
      
  
    
    public Lote obtenerPedidoEn (int fila) {
        return lotes.get(fila);
    }

    public void setPedidos(List<Lote> lotes) {
        this.lotes = lotes;
    }
    
    
}
